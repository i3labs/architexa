/*  OMM - Ontology Middleware Module
 *  Copyright (C) 2002 OntoText Lab, Sirma AI OOD
 *
 *  Contact:
 *	Sirma AI OOD, OntoText Lab.
 *	38A, Christo Botev Blvd.
 *  1000 Sofia, Bulgaria
 *	tel. +359(2)981 00 18
 *	fax. +359(2)981 90 58
 *	info@ontotext.com
 *
 * 	http://www.ontotext.com/
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.openrdf.sesame.omm;

/**
 * Title:        OTK: SAIL interface definitions
 * Description:  This code is a part of OnTo-Knowledge project.
 * Company:      Sirma AI - OntoText Lab.
 * @author Damyan Ognyanoff
 * @version 1.0
 */

import org.openrdf.sesame.sail.Sail;


/**
 * inteface TrackingChanges provides the basic operations to track the state of
 * various items in the repository during their life-time
 */
public interface TrackingChanges extends Sail {
//  /**
//   * Retrive the meta-information for a particular statement in the repository
//   * @param statement to track
//   * @returns Hitory interface to access the meta-information abot this statement
//   */
//  public History getStatementHistory(Statement statement);
//
//  /**
//   * Retrive the metainformation collected during the life-time of the repository
//   * @return list of History intefaces for distinct operations made in the repository
//   */
//  public Iterator getRepositoryHistory();
//
//  /**
//   * Clear the Histroy from the repository. In order invoke that method th euser
//   * must have the HISTORY permition for the repository.
//   * @param clearMethod. If true the clear operation rearanges the
//   * calendar (all the values of the update counter). all items born before
//   */
//  public void clearHistory(long UID, boolean rearangeCalendar);
//
//  /**
//   * Aggregate a number of sequential updates (say, between UID1 and UID2) to be
//   * merged and made equivalent to specified one, say UID3. In this case, all
//   * references to UIDs between UID1 and UID2 will be replaced with UID3,
//   * which may or may not be equal to UID1 and UID2
//   * @param update state to begin
//   * @param update state to end
//   */
//  public void aggregateUpdates(long UID1, long UID2);
//
//  /**
//   * Retrieve the meta-information about particular repository state.
//   * @param value of the update counter
//   * @returns list of Map intefaces containing the meta-information
//   */
//  public Iterator retrieveMetaInfo(long stateUID);
//} // TrackingChanges interface
//
///**
// * interface History. The purpose of this inteface is to access the meta-information
// * about a statement.
// */
//interface History {
//  /**
//   * Retrive the value of the update counter when this statement iwas asserted
//   * to the repository.
//   * @returns value of the update counter
//   */
//  long bornAtState();
//
//  /**
//   * Retrieve the user id of the user who added this statement in the repository
//   * @returns userID
//   */
//  String addedByUser();
//
//  /**
//   * Retrive the value of the update counter when this statement was removed
//   * from the repository.
//   * @returns value of the update counter
//   */
//  long diedAtState();
//
//  /**
//   * Retrieve the user id of the user who removed the statement from the repository
//   * @returns userID
//   */
//  String removedByUser();
} // History
