/*  Sesame - Storage and Querying architecture for RDF and RDF Schema
 *  Copyright (C) 2001-2006 Aduna
 *
 *  Contact:
 *  	Aduna
 *  	Prinses Julianaplein 14 b
 *  	3817 CS Amersfoort
 *  	The Netherlands
 *  	tel. +33 (0)33 465 99 87
 *  	fax. +33 (0)33 465 99 87
 *
 *  	http://aduna-software.com/
 *  	http://www.openrdf.org/
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package org.openrdf.sesame.sail.query;

import java.util.Collection;

import org.openrdf.model.Value;

import org.openrdf.sesame.sail.RdfSource;

/**
 * Checks whether a certain value is contained in a set of results
 * produced by a query.
 */
public class In implements BooleanExpr {

/*----------+
| Variables |
+----------*/

	private ValueExpr _leftArg;
	private Query _rightArg;

/*-------------+
| Constructors |
+-------------*/

	public In(ValueExpr leftArg, Query rightArg) {
		_leftArg = leftArg;
		_rightArg = rightArg;
	}

/*--------+
| Methods |
+--------*/

	public ValueExpr getLeftArg() {
		return _leftArg;
	}

	public Query getRightArg() {
		return _rightArg;
	}

	public void getVariables(Collection variables) {
		_leftArg.getVariables(variables);
		_rightArg.getVariables(variables);
	}

	public boolean isTrue(RdfSource rdfSource)
		throws SailQueryException
	{
		MembershipTester mst = new MembershipTester( _leftArg.getValue() );

		_rightArg.evaluate(rdfSource, mst);

		return mst.isMember();
	}

	public String toString() {
		return _leftArg + " IN (" + _rightArg + ")";
	}

/*-----------------------------+
| Inner class MembershipTester |
+-----------------------------*/

	private static class MembershipTester implements QueryAnswerListener {

		private Value _leftValue;
		private boolean _isMember = false;

		public MembershipTester(Value leftValue) {
			_leftValue = leftValue;
		}

		// implements QueryAnswerListener.queryAnswer(QueryAnswer)
		public boolean queryAnswer(QueryAnswer qa) {
			// Check if this next query answer matches
			Value rightValue = qa.getValue(0);

			_isMember =
				_leftValue == null && rightValue == null ||
				_leftValue != null && _leftValue.equals(rightValue);

			// Continue evaluation until a match has been found
			return !_isMember;
		}

		// implements QueryAnswerListener.clear()
		public void clear() {
		}

		public boolean isMember() {
			return _isMember;
		}
	}
}
