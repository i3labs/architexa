/*  Sesame - Storage and Querying architecture for RDF and RDF Schema
 *  Copyright (C) 2001-2006 Aduna
 *
 *  Contact:
 *  	Aduna
 *  	Prinses Julianaplein 14 b
 *  	3817 CS Amersfoort
 *  	The Netherlands
 *  	tel. +33 (0)33 465 99 87
 *  	fax. +33 (0)33 465 99 87
 *
 *  	http://aduna-software.com/
 *  	http://www.openrdf.org/
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package org.openrdf.sesame.sailimpl.nativerdf.model;

import org.openrdf.model.GraphException;
import org.openrdf.model.URI;
import org.openrdf.model.Value;
import org.openrdf.model.impl.URIImpl;

import org.openrdf.sesame.sail.SailUpdateException;
import org.openrdf.sesame.sail.StatementIterator;
import org.openrdf.sesame.sailimpl.nativerdf.NativeRdfRepository;
import org.openrdf.sesame.sailimpl.nativerdf.ValueStoreRevision;

public class NativeURI extends URIImpl implements NativeResource {

	/*----------+
	 | Variables |
	 +----------*/

	transient private NativeRdfRepository _repository;

	transient private ValueStoreRevision _revision;

	transient private int _id;

	/*-------------+
	 | Constructors |
	 +-------------*/

	public NativeURI(NativeRdfRepository repository, String uri) {
		super(uri);
		_repository = repository;
	}

	public NativeURI(NativeRdfRepository repository, String namespace, String localname) {
		super(namespace, localname);
		_repository = repository;
	}

	public NativeURI(NativeRdfRepository repository, URI uri) {
		this(repository, uri.getNamespace(), uri.getLocalName());
	}

	/*--------+
	 | Methods |
	 +--------*/

	public NativeRdfRepository getRepository() {
		return _repository;
	}

	public void setInternalId(int id, ValueStoreRevision revision) {
		_id = id;
		_revision = revision;
	}

	public int getInternalId() {
		return _id;
	}

	public ValueStoreRevision getValueStoreRevision() {
		return _revision;
	}

	// implements Resource.getSubjectStatements()
	public StatementIterator getSubjectStatements()
		throws GraphException
	{
		if (_repository == null) {
			throw new GraphException("no backing store associated");
		}

		return _repository.getStatements(this, null, null);
	}

	// implements URI.getPredicateStatements()
	public StatementIterator getPredicateStatements()
		throws GraphException
	{
		if (_repository == null) {
			throw new GraphException("no backing store associated");
		}

		return _repository.getStatements(null, this, null);
	}

	// implements Resource.getObjectStatements()
	public StatementIterator getObjectStatements()
		throws GraphException
	{
		if (_repository == null) {
			throw new GraphException("no backing store associated");
		}

		return _repository.getStatements(null, null, this);
	}

	// implements URI.addProperty(URI, Value)
	public void addProperty(URI property, Value value)
		throws GraphException
	{
		if (_repository == null) {
			throw new GraphException("no backing store associated");
		}

		_repository.startTransaction();
		try {
			_repository.addStatement(this, property, value);
		}
		catch (SailUpdateException e) {
			throw new GraphException(e);
		}
		finally {
			_repository.commitTransaction();
		}
	}
}
